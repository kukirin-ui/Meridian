# G-01 The ideation engine — stage contract

Graphics Master · Imagination core · ideas, taste, direction · Evidence B

## Inputs
- Skill card: `references/G-01.md` (six fields).
- Practice tasks: generated from the card's "How it is learned" protocol.
- Prior lessons for this skill: `output/`.
- Sources: the tree's `bibliography.md`.

## Process
1. Practice: run tasks from the card's learning protocol.
2. Judge: a blind judge or panel (imagination skill). Every creative stage has a checkpoint and an audit.
3. Reflect: write what failed and why.
4. Store lesson: short lesson file into `output/`; into `references/` only after verification.

## Outputs
- Practice results and logged lessons in `output/`.
- Pass condition: the card's "Signs of mastery", without its failure mode.

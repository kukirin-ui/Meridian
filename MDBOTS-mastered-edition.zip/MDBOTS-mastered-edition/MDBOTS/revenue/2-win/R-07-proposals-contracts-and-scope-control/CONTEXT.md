# R-07 Proposals, contracts and scope control — stage contract

Revenue Layer · Stage 2 · Win · Evidence A

## Inputs
- Skill card: `references/R-07.md` (six fields).
- Practice tasks: generated from the card's "How it is learned" protocol.
- Prior lessons for this skill: `output/`.
- Sources: the tree's `bibliography.md`.

## Process
1. Practice: run tasks from the card's learning protocol.
2. Measure: check results against the card's "Proof it works". Before any payment, contract, new account, public post or message to a new person: human approval (R-16).
3. Reflect: write what failed and why.
4. Store lesson: short lesson file into `output/`; into `references/` only after verification.

## Outputs
- Practice results and logged lessons in `output/`.
- Pass condition: the card's "Proof it works", with its guardrail kept.
